# Security Policy

## Supported Versions

Currently, only the `main` branch is "supported". 

| Version | Supported          |
| ------- | ------------------ |
| `main`  | :white_check_mark: |

## Reporting a Vulnerability

Please email `contact@jread.com` for responsible disclosure. Accepted issues will be made public once patched, and you will be given credit. 
